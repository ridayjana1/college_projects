//
//  main.cpp
//  Assignment_Q2
//
//  Created by Riday Jana on 9/19/24.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int wager;
int user;
int rollDice(){
    return rand() % 6 + 1;
}

void playgame(){
    srand(static_cast<unsigned int>(time(0)));
    int playerMoney = 100;
    while(playerMoney > 0){
        cout << "Current Balance: " << playerMoney << endl;
        cout << "Enter your wager" << endl;
        cin >> wager;
        
        if (wager <= 0 || playerMoney < wager){
            cout << "You cannot wager more than you current balance." << endl;
            continue;
        }
        
        
        cout << "Select a number (1-6)" << endl;
        cin >> user;
        
        while(user < 1 || user > 6){
            cout << "Invalid number. Please enter a valid number (1-6)" << endl;
            cout << "Select a number 1-6" << endl;
            cin >> user;
            }
        //3 dice
        int roll1 = rollDice();
        int roll2 = rollDice();
        int roll3 = rollDice();
        
        cout << "Rolled dice are: " << roll1 << " " << roll2 << " " << roll3 << endl;
        
        int matchCount = 0;
        if (roll1 == user){
            matchCount++;
        }
        if (roll2 == user){
            matchCount++;
        }
        if (roll3 == user){
            matchCount++;
        }
        
        //Determine outcome
        if (matchCount == 0) {
            playerMoney -= wager;
            cout << "You lose your wager of " << wager << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 1) {
            cout << "You win your wager back: " << wager << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 2) {
                playerMoney += wager * 2;
                cout << "You win: " << wager * 2 << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 3) {
                playerMoney += wager * 3; // Bonus for all three matching
                cout << "Jackpot! You win: " << wager * 3 << ". New balance: " << playerMoney << endl;
                }
        cout << "Current balance: " << playerMoney << endl;
        cout << " Do you want to play again? (y/n): " << endl;
        char choice;
        cin >> choice;
        if (choice == 'n'){
            break;
        }
        cout << "Game over! Your final balance is: " << playerMoney << endl;
    }
    
}
int main(){
    playgame();
    return 0;
}
