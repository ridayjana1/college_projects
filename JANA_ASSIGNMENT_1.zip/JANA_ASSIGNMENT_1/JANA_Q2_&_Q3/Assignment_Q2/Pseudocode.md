#  PseudoCode
FUNCTION rollDice():
    RETURN random number between 1 and 6

FUNCTION playGame():
    SET playerMoney = 100
    WHILE playerMoney > 0:
        PRINT "Current balance: ", playerMoney
        PROMPT "Enter your wager (amount): "
        READ wager
        
        IF wager > playerMoney THEN
            PRINT "You cannot wager more than your current balance."
            CONTINUE
        
        PROMPT "Select a number (1-6): "
        READ selectedNumber
        
        WHILE selectedNumber < 1 OR selectedNumber > 6:
            PRINT "Invalid number. Please enter a valid number (1-6)."
            PROMPT "Select a number (1-6): "
            READ selectedNumber
        
        // Roll three dice
        SET roll1 = rollDice()
        SET roll2 = rollDice()
        SET roll3 = rollDice()
        
        PRINT "Dice rolled: ", roll1, roll2, roll3
        
        SET matchCount = 0
        IF roll1 == selectedNumber THEN
            INCREMENT matchCount
        IF roll2 == selectedNumber THEN
            INCREMENT matchCount
        IF roll3 == selectedNumber THEN
            INCREMENT matchCount
        
        // Determine outcome
        IF matchCount == 0 THEN
            PRINT "You lose your wager of ", wager
            DECREMENT playerMoney by wager
        ELSE IF matchCount == 1 THEN
            PRINT "You win your wager back: ", wager
            playerMoney = playerMoney // no change
        ELSE IF matchCount == 2 THEN
            PRINT "You win ", wager * 2
            INCREMENT playerMoney by wager
        ELSE IF matchCount == 3 THEN
            PRINT "You win ", wager * 3
            INCREMENT playerMoney by wager * 2 // gain from the original wager
        
        PRINT "Current balance: ", playerMoney

        PROMPT "Do you want to play again? (y/n): "
        READ choice
        IF choice == 'n' THEN
            BREAK

    PRINT "Game over! Your final balance is: ", playerMoney

// Main program starts here
CALL playGame()


#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int wager;
int user;

int rollDice() {
    return rand() % 6 + 1;
}

void playgame() {
    srand(static_cast<unsigned int>(time(0))); // Seed the random number generator
    int playerMoney = 100;

    while (playerMoney > 0) {
        cout << "Current Balance: " << playerMoney << endl;
        cout << "Enter your wager: ";
        cin >> wager;

        // Ensure wager is positive and not more than playerMoney
        if (wager <= 0 || wager > playerMoney) {
            cout << "You cannot wager more than your current balance or less than 1." << endl;
            continue;
        }

        cout << "Select a number (1-6): ";
        cin >> user;

        while (user < 1 || user > 6) {
            cout << "Invalid number. Please enter a valid number (1-6): ";
            cin >> user;
        }

        // Roll 3 dice
        int roll1 = rollDice();
        int roll2 = rollDice();
        int roll3 = rollDice();

        cout << "Rolled dice are: " << roll1 << " " << roll2 << " " << roll3 << endl;

        int matchCount = 0;
        if (roll1 == user) matchCount++;
        if (roll2 == user) matchCount++;
        if (roll3 == user) matchCount++;

        // Determine outcome
        if (matchCount == 0) {
            playerMoney -= wager;
            cout << "You lose your wager of " << wager << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 1) {
            cout << "You win your wager back: " << wager << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 2) {
            playerMoney += wager * 2;
            cout << "You win: " << wager * 2 << ". New balance: " << playerMoney << endl;
        } else if (matchCount == 3) {
            playerMoney += wager * 3; // Bonus for all three matching
            cout << "Jackpot! You win: " << wager * 3 << ". New balance: " << playerMoney << endl;
        }

        // Check if player wants to play again
        char choice;
        cout << "Do you want to play again? (y/n): ";
        cin >> choice;
        if (choice == 'n') {
            break;
        }
    }

    cout << "Game over! Your final balance is: " << playerMoney << endl;
}

int main() {
    playgame();
    return 0;
}


