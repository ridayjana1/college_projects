# Assignment #1 README
## Tasks
### 1. Benford's Law (30 points)

**Description:**  
Write a C++ program that reads a collection of naturally occurring numbers (e.g., UAA enrollments) and counts how many start with each digit from 1 to 9. The program should read numbers from the console using I/O redirection.

**Implementation Steps:**
- Use an array to count the leading digits.
- Read input via `cin`.
- Output the count of each leading digit.

**Example Command:**  
```bash
./getLeadingDigits < enrollments.txt
```

### 2. Chuck-a-luck (30 points)

**Description:**  
Implement a simple dice game where the player wagers and chooses a number between 1-6. The game simulates rolling three dice and calculates winnings based on the rules provided.

**Implementation Steps:**
- Allow the player to input a wager and select a number.
- Simulate rolling three six-sided dice.
- Determine winnings based on the number of matches.
- Keep the player playing until they choose to quit or run out of money.

**Key Functions:**
- Use at least one programmer-defined function to handle game logic.

### 3. Maze Generation and Maze Solving (20 points)

**Description:**  
This part does not require coding. You need to describe an algorithm to find the exit of a maze represented by a 2-D array without using recursion. 

**Algorithm Requirements:**
- Avoid going in circles.
- Utilize a systematic approach to explore the maze (e.g., BFS).

**Maze Generation Criteria:**
- Discuss the criteria for a good maze (solvability, complexity, randomness).
- Describe how your maze generation algorithm meets these criteria.

### 4. Reference Parameters (20 points)

**Description:**  
Create a program that calculates the minimum number of coins needed to dispense a certain amount of change (1-99 cents). 

**Implementation Steps:**
- Define a void function that calculates the number of quarters, dimes, nickels, and pennies.
- Use reference parameters to return the counts.
- Write test cases in the main function to demonstrate functionality.

**Example Function Signature:**
```cpp
void calculateChange(int amount, int &quarters, int &dimes, int &nickels, int &pennies);
```

## Testing and Output

- Ensure your programs handle edge cases (e.g., invalid input for Chuck-a-luck).
- Test all programs with at least two test cases for the change calculation.


