#include <iostream>
using namespace std;

int getLeadingDigits(int num){
    while (num >= 10){
        num /= 10; //This function repeatedly divides the number by 10 until it>
    }
    return num;
}

int main(){
    int counts[9] = {0}; //Initializing all the counts to 0;
    int num;
    
    while(cin >> num){
        int LeadingDigits = getLeadingDigits(num);
        if (LeadingDigits >= 1 && LeadingDigits <= 9){
            counts[LeadingDigits - 1]++; // Increment the count for the corresp>
        }
    }
    cout << "Leading Digits" <<endl;
    for (int i = 0; i < 9; i++){
        cout << (i+1) << " : " << counts[i] << endl;
    }
    return 0;
}
