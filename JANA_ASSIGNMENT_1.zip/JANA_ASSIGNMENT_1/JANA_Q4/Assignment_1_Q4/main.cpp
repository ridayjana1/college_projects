//
//  main.cpp
//  Assignment_1_Q4
//
//  Created by Riday Jana on 9/19/24.
//

#include <iostream>

using namespace std;

void calculateCoins(int amount, int& quarters, int& dime, int& nickels, int& pennies){
    
    quarters = amount / 25;
    amount %= 25;
    
    dime = amount / 10;
    amount %= 10;
    
    nickels = amount / 5;
    amount %= 5;
    
    pennies = amount;
    
};

int main(){
    int amount;
    cout << "Write a amount between (1-99): " << endl;
    cin >> amount;
    
    if(amount < 1 || amount > 99){
        cout << "You have to write a number between 1-99" << endl;
        return 1;
    }
    int quarters, dime, nickels, pennies;
    
    calculateCoins(amount, quarters, dime, nickels, pennies);
    
    cout << "To make " << amount << " cents, you need:" <<endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dime << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;

    return 0;
}


